Sample's module added column to order grid without creating columns in sales_order_grid table. Tested in magento 2.1.4. Be sure, code as is.
For me, it looks like this http://pix.toile-libre.org/upload/original/1491744375.png
